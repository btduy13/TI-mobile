from PIL import Image, ImageDraw, ImageFont
import os

# Create directory if it doesn't exist
os.makedirs("assets/images", exist_ok=True)

# Create a 512x512 image with a white background
icon_size = 512
image = Image.new('RGBA', (icon_size, icon_size), (255, 255, 255, 255))
draw = ImageDraw.Draw(image)

# Draw a blue rectangle as background
draw.rectangle([(0, 0), (icon_size, icon_size)], fill=(41, 128, 185, 255))

# Draw a tape roll icon (simplified)
# Outer circle
draw.ellipse([(icon_size/4, icon_size/4), (3*icon_size/4, 3*icon_size/4)], 
             fill=(236, 240, 241, 255), outline=(52, 73, 94, 255), width=5)

# Inner circle
draw.ellipse([(icon_size/3, icon_size/3), (2*icon_size/3, 2*icon_size/3)], 
             fill=(189, 195, 199, 255), outline=(52, 73, 94, 255), width=3)

# Save the icon in different sizes
sizes = [512, 256, 128, 64, 48, 36, 24]

for size in sizes:
    resized_image = image.resize((size, size), Image.LANCZOS)
    resized_image.save(f"assets/images/icon_{size}.png")

# Save the main icon
image.save("assets/images/icon.png")

print("Icons created successfully in assets/images/ directory") 