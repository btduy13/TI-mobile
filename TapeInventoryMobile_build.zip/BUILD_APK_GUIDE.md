# Guide to Building the Tape Inventory Management APK

This guide provides instructions for building the Tape Inventory Management application as an Android APK that can be installed on Android devices.

## Prerequisites

- Python 3.8 or higher
- Pip package manager
- Internet connection

## Option 1: Using Windows Subsystem for Linux (WSL) - Recommended for Windows Users

### Step 1: Install WSL and Ubuntu

1. Open PowerShell as Administrator and run:
   ```
   wsl --install
   ```
   This will install WSL 2 and Ubuntu by default.

2. Restart your computer when prompted.

3. After restart, Ubuntu will open and ask you to create a username and password.

### Step 2: Set up the build environment in Ubuntu

1. Update the package lists:
   ```
   sudo apt update
   ```

2. Install required dependencies:
   ```
   sudo apt install -y git zip unzip openjdk-17-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
   ```

3. Install Python dependencies:
   ```
   pip3 install --user --upgrade Cython==0.29.33 virtualenv buildozer
   ```

4. Add the local bin directory to your PATH:
   ```
   echo 'export PATH=$PATH:~/.local/bin/' >> ~/.bashrc
   source ~/.bashrc
   ```

### Step 3: Copy your project to WSL

1. Copy your project from Windows to WSL:
   ```
   cp -r /mnt/c/path/to/TapeInventoryMobile ~/TapeInventoryMobile
   ```

2. Navigate to your project directory:
   ```
   cd ~/TapeInventoryMobile
   ```

### Step 4: Build the APK

1. Initialize buildozer if you haven't already:
   ```
   buildozer init
   ```

2. Build the debug APK:
   ```
   buildozer android debug
   ```

3. The APK will be generated in the `bin` directory.

## Option 2: Using Docker

### Step 1: Install Docker

1. Download and install Docker Desktop from [https://www.docker.com/products/docker-desktop/](https://www.docker.com/products/docker-desktop/)

2. Start Docker Desktop and ensure it's running.

### Step 2: Build and run the Buildozer Docker container

1. Open a terminal/command prompt and navigate to your project directory:
   ```
   cd path/to/TapeInventoryMobile
   ```

2. Create a Dockerfile in your project directory:
   ```
   FROM kivy/buildozer:latest

   WORKDIR /app
   ```

3. Build the Docker image:
   ```
   docker build -t tapeinventory-builder .
   ```

4. Run the Docker container to build your APK:
   ```
   docker run --volume "%cd%":/app tapeinventory-builder buildozer android debug
   ```

5. The APK will be generated in the `bin` directory.

## Option 3: Using Google Colab (Cloud-based)

If you're having trouble with local setup, you can use Google Colab to build your APK:

1. Create a new Colab notebook at [https://colab.research.google.com/](https://colab.research.google.com/)

2. Run the following commands in separate cells:

   ```python
   !pip install buildozer
   !pip install cython==0.29.33
   !sudo apt-get install -y \
       python3-pip \
       build-essential \
       git \
       python3 \
       python3-dev \
       ffmpeg \
       libsdl2-dev \
       libsdl2-image-dev \
       libsdl2-mixer-dev \
       libsdl2-ttf-dev \
       libportmidi-dev \
       libswscale-dev \
       libavformat-dev \
       libavcodec-dev \
       zlib1g-dev
   !sudo apt-get install -y \
       libgstreamer1.0 \
       gstreamer1.0-plugins-base \
       gstreamer1.0-plugins-good
   !sudo apt-get install -y \
       build-essential \
       libsqlite3-dev \
       sqlite3 \
       bzip2 \
       libbz2-dev \
       zlib1g-dev \
       libssl-dev \
       openssl \
       libgdbm-dev \
       libgdbm-compat-dev \
       liblzma-dev \
       libreadline-dev \
       libncursesw5-dev \
       libffi-dev \
       uuid-dev \
       libffi6
   !sudo apt-get install -y libffi-dev
   ```

   ```python
   # Clone your repository (or upload your files)
   !git clone https://github.com/yourusername/TapeInventoryMobile.git
   %cd TapeInventoryMobile
   ```

   ```python
   # Initialize buildozer
   !buildozer init
   ```

   ```python
   # Build the APK
   !buildozer android debug
   ```

   ```python
   # Download the APK
   from google.colab import files
   files.download('bin/tapeinventory-0.1-debug.apk')
   ```

## Installing the APK on Your Android Device

1. Transfer the APK file to your Android device using USB, email, or cloud storage.

2. On your Android device, navigate to the APK file and tap on it.

3. If prompted, enable "Install from Unknown Sources" in your device settings.

4. Follow the on-screen instructions to install the app.

5. Once installed, you can open the Tape Inventory Management app from your app drawer.

## Troubleshooting

- If you encounter errors during the build process, check the buildozer log file at `.buildozer/logs/buildozer.log`.

- For WSL users, if you need to access the APK from Windows, you can find it at `\\wsl$\Ubuntu\home\yourusername\TapeInventoryMobile\bin\`.

- If you get "Aidl not found" error, run: `~/.buildozer/android/platform/android-sdk/tools/bin/sdkmanager "build-tools;29.0.0"` and press "y" to accept the license.

- For more detailed troubleshooting, refer to the [Buildozer documentation](https://buildozer.readthedocs.io/). 