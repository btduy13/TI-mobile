"""
This script generates a Google Colab notebook that can be used to build the APK.
Run this script and upload the generated notebook to Google Colab.
"""

import json
import os

# Define the notebook structure
notebook = {
    "cells": [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# Build Tape Inventory Management APK\n",
                "\n",
                "This notebook will help you build an Android APK for the Tape Inventory Management application.\n",
                "\n",
                "## Step 1: Install dependencies"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "!pip install buildozer\n",
                "!pip install cython==0.29.33\n",
                "!sudo apt-get update\n",
                "!sudo apt-get install -y \\\n",
                "    python3-pip \\\n",
                "    build-essential \\\n",
                "    git \\\n",
                "    python3 \\\n",
                "    python3-dev \\\n",
                "    ffmpeg \\\n",
                "    libsdl2-dev \\\n",
                "    libsdl2-image-dev \\\n",
                "    libsdl2-mixer-dev \\\n",
                "    libsdl2-ttf-dev \\\n",
                "    libportmidi-dev \\\n",
                "    libswscale-dev \\\n",
                "    libavformat-dev \\\n",
                "    libavcodec-dev \\\n",
                "    zlib1g-dev\n",
                "!sudo apt-get install -y \\\n",
                "    libgstreamer1.0 \\\n",
                "    gstreamer1.0-plugins-base \\\n",
                "    gstreamer1.0-plugins-good\n",
                "!sudo apt-get install -y \\\n",
                "    build-essential \\\n",
                "    libsqlite3-dev \\\n",
                "    sqlite3 \\\n",
                "    bzip2 \\\n",
                "    libbz2-dev \\\n",
                "    zlib1g-dev \\\n",
                "    libssl-dev \\\n",
                "    openssl \\\n",
                "    libgdbm-dev \\\n",
                "    libgdbm-compat-dev \\\n",
                "    liblzma-dev \\\n",
                "    libreadline-dev \\\n",
                "    libncursesw5-dev \\\n",
                "    libffi-dev \\\n",
                "    uuid-dev \\\n",
                "    libffi6\n",
                "!sudo apt-get install -y libffi-dev"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 2: Upload your project files\n",
                "\n",
                "You can either upload a zip file containing your project or upload individual files. If you're uploading a zip file, use the following cell to extract it:"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from google.colab import files\n",
                "import os\n",
                "import shutil\n",
                "\n",
                "# Create project directory\n",
                "!mkdir -p TapeInventoryMobile\n",
                "\n",
                "# Option 1: Upload a zip file\n",
                "print(\"Please upload your project zip file...\")\n",
                "uploaded = files.upload()\n",
                "\n",
                "for filename in uploaded.keys():\n",
                "    if filename.endswith('.zip'):\n",
                "        print(f\"Extracting {filename}...\")\n",
                "        !unzip -o \"{filename}\" -d TapeInventoryMobile\n",
                "        print(\"Extraction complete!\")\n",
                "    else:\n",
                "        print(f\"Skipping {filename} as it's not a zip file.\")\n",
                "\n",
                "# Option 2: If you prefer to upload individual files, you can do that in the next cell"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "If you prefer to upload individual files instead of a zip, use this cell to upload them:"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "# Option 2: Upload individual files\n",
                "print(\"Please upload your project files (you can select multiple files)...\")\n",
                "uploaded_files = files.upload()\n",
                "\n",
                "for filename in uploaded_files.keys():\n",
                "    # Save the file to the project directory\n",
                "    with open(f\"TapeInventoryMobile/{filename}\", 'wb') as f:\n",
                "        f.write(uploaded_files[filename])\n",
                "    print(f\"Saved {filename} to TapeInventoryMobile/\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 3: Navigate to the project directory and initialize buildozer"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "%cd TapeInventoryMobile\n",
                "!ls -la\n",
                "\n",
                "# Initialize buildozer if buildozer.spec doesn't exist\n",
                "if not os.path.exists('buildozer.spec'):\n",
                "    !buildozer init\n",
                "    print(\"Buildozer initialized with default spec file.\")\n",
                "else:\n",
                "    print(\"Buildozer spec file already exists.\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 4: Build the APK\n",
                "\n",
                "This step will take some time. Buildozer will download and set up the Android SDK, NDK, and other dependencies before building the APK."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "!buildozer android debug"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 5: Download the APK\n",
                "\n",
                "If the build was successful, you can download the APK file."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "from google.colab import files\n",
                "import glob\n",
                "\n",
                "# Find the APK file\n",
                "apk_files = glob.glob('bin/*.apk')\n",
                "\n",
                "if apk_files:\n",
                "    for apk_file in apk_files:\n",
                "        print(f\"Downloading {apk_file}...\")\n",
                "        files.download(apk_file)\n",
                "else:\n",
                "    print(\"No APK files found in the bin directory. The build may have failed.\")\n",
                "    print(\"Check the buildozer log for errors:\")\n",
                "    !cat .buildozer/logs/buildozer.log | tail -n 100"
            ]
        }
    ],
    "metadata": {
        "colab": {
            "name": "Build Tape Inventory Management APK",
            "provenance": [],
            "collapsed_sections": []
        },
        "kernelspec": {
            "display_name": "Python 3",
            "name": "python3"
        },
        "language_info": {
            "name": "python"
        }
    },
    "nbformat": 4,
    "nbformat_minor": 0
}

# Save the notebook to a file
with open('build_apk_colab.ipynb', 'w') as f:
    json.dump(notebook, f, indent=2)

print("Colab notebook generated: build_apk_colab.ipynb")
print("Upload this notebook to Google Colab to build your APK.") 